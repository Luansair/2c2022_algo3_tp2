package edu.fiuba.algo3.modelo.codigo.obstaculos;

import edu.fiuba.algo3.modelo.codigo.vehiculos.Vehiculo;

public interface Obstaculo {
    void activar(Vehiculo unVehiculo);
}
