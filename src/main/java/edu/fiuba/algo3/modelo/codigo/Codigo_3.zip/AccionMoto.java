package edu.fiuba.algo3.modelo.codigo;

public interface AccionMoto {

    public void realizar(Esquina esquina);
}
