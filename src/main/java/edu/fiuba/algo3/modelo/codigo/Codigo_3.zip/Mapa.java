package edu.fiuba.algo3.modelo.codigo;

import edu.fiuba.algo3.modelo.codigo.vehiculos.Vehiculo;

public class Mapa {
    private Cuadra cuadras;

    public void aplicarObstaculos(Vehiculo unVehiculo, Esquina esquinaUno, Esquina esquinaDos) {
        if (cuadras.mismaCuadra(esquinaUno, esquinaDos)) {
            cuadras.aplicarObstaculos(unVehiculo);
        }
    }

    public void agregarCuadra(Cuadra cuadra) {
        this.cuadras = cuadra;
    }
}
