package edu.fiuba.algo3.modelo.codigo;

import java.util.ArrayList;

public class Juego {
    private Jugador jugador;


    public Juego(Jugador unJugador) {
        this.jugador = unJugador;
    }
}
