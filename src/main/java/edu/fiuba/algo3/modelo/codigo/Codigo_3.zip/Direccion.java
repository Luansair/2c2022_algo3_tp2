package edu.fiuba.algo3.modelo.codigo;

public abstract class Direccion {
    protected Mapa mapa;

    abstract public void mover(Esquina unaEsquina);
}
